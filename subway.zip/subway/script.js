const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const WIDTH = canvas.width;
const HEIGHT = canvas.height;

// Load assets
const bgImg = new Image();
bgImg.src = "background.png";

const playerImg = new Image();
playerImg.src = "player.png";

const coinImg = new Image();
coinImg.src = "coin.png";

const obsImg = new Image();
obsImg.src = "obstacle.png";

// Game state
let score = 0;
let bgY = 0;
let keys = {};

const player = {
  x: WIDTH / 2 - 25,
  y: HEIGHT - 150,
  width: 80,
  height: 80,
  speed: 10
};

let obstacles = [];
let coins = [];

// Controls
document.addEventListener("keydown", (e) => keys[e.key] = true);
document.addEventListener("keyup", (e) => keys[e.key] = false);

function handlePlayerMovement() {
  if (keys["ArrowLeft"]) {
    player.x = Math.max(0, player.x - player.speed);
  }
  if (keys["ArrowRight"]) {
    player.x = Math.min(WIDTH - player.width, player.x + player.speed);
  }
}

function drawBackground() {
  ctx.drawImage(bgImg, 0, bgY, WIDTH, HEIGHT);
  ctx.drawImage(bgImg, 0, bgY - HEIGHT, WIDTH, HEIGHT);
  bgY += 4;
  if (bgY >= HEIGHT) bgY = 0;
}

function drawPlayer() {
  ctx.drawImage(playerImg, player.x, player.y, player.width, player.height);
}

function drawObstacles() {
  obstacles.forEach(obs => {
    obs.y += 6;
    ctx.drawImage(obsImg, obs.x, obs.y, obs.size, obs.size);
  });
}

function drawCoins() {
  coins.forEach(coin => {
    coin.y += 4;
    ctx.drawImage(coinImg, coin.x, coin.y, 40, 40);
  });
}

function detectCollision(a, b) {
  return (
    a.x < b.x + b.size &&
    a.x + a.width > b.x &&
    a.y < b.y + b.size &&
    a.y + a.height > b.y
  );
}

function detectCoinCollection(player, coin) {
  return (
    player.x < coin.x + 40 &&
    player.x + player.width > coin.x &&
    player.y < coin.y + 40 &&
    player.y + player.height > coin.y
  );
}

function generateObstacle() {
  const x = Math.floor(Math.random() * (WIDTH - 50));
  obstacles.push({ x: x, y: -60, size: 50 });
}

function generateCoin() {
  const x = Math.floor(Math.random() * (WIDTH - 40));
  coins.push({ x: x, y: -60 });
}

function drawScore() {
  ctx.fillStyle = "white";
  ctx.font = "24px Arial";
  ctx.fillText("Score: " + score, 30, 40);
}

function gameLoop() {
  ctx.clearRect(0, 0, WIDTH, HEIGHT);

  drawBackground();
  handlePlayerMovement();
  drawPlayer();
  drawObstacles();
  drawCoins();
  drawScore();

  // Collision detection
  obstacles = obstacles.filter(obs => {
    if (detectCollision(player, obs)) {
      alert("Game Over! Your Score: " + score);
      document.location.reload();
      return false;
    }
    return obs.y < HEIGHT;
  });

  coins = coins.filter(coin => {
    if (detectCoinCollection(player, coin)) {
      score++;
      return false;
    }
    return coin.y < HEIGHT;
  });

  requestAnimationFrame(gameLoop);
}

// Spawning intervals
setInterval(generateObstacle, 1500);
setInterval(generateCoin, 1200);

// Start game
gameLoop();
