const board = document.getElementById("board");
const statusText = document.getElementById("status");
const winMessage = document.getElementById("winMessage");
const winText = document.getElementById("winText");

let currentPlayer = "X";
let gameActive = true;
let gameState = Array(9).fill("");

const winningCombos = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6]
];

// Handle click on a cell
function handleCellClick(index) {
  if (!gameActive) return;

  if (gameState[index] !== "") {
    const cells = document.querySelectorAll(".cell");
    const cell = cells[index];
    cell.classList.add("invalid");
    setTimeout(() => cell.classList.remove("invalid"), 500);
    return;
  }

  gameState[index] = currentPlayer;
  renderBoard();

  if (checkWinner()) {
    highlightWinningCells();
    showWinnerText(`${currentPlayer} Wins!`);
    gameActive = false;
  } else if (!gameState.includes("")) {
    showWinnerText("It's a Draw!");
    gameActive = false;
  } else {
    currentPlayer = currentPlayer === "X" ? "O" : "X";
    statusText.textContent = `Player ${currentPlayer}'s turn`;
  }
}

// Check if current state has a winner
function checkWinner() {
  return winningCombos.some(([a, b, c]) => {
    return (
      gameState[a] &&
      gameState[a] === gameState[b] &&
      gameState[a] === gameState[c]
    );
  });
}

// Return the winning combination (if any)
function getWinningCombo() {
  return winningCombos.find(([a, b, c]) => {
    return (
      gameState[a] &&
      gameState[a] === gameState[b] &&
      gameState[a] === gameState[c]
    );
  }) || [];
}

// Add glow animation to winning cells
function highlightWinningCells() {
  const combo = getWinningCombo();
  const cells = document.querySelectorAll(".cell");
  combo.forEach(index => {
    cells[index].classList.add("winner");
  });
}

// Create or re-render the board
function renderBoard() {
  board.innerHTML = "";
  gameState.forEach((cell, index) => {
    const div = document.createElement("div");
    div.classList.add("cell");
    if (cell !== "") div.classList.add("filled");
    div.textContent = cell;
    div.addEventListener("click", () => handleCellClick(index));
    board.appendChild(div);
  });
}

// Restart the game state
function restartGame() {
  currentPlayer = "X";
  gameActive = true;
  gameState = Array(9).fill("");
  statusText.textContent = `Player ${currentPlayer}'s turn`;
  winMessage.classList.add("hidden");
  renderBoard();
}

// Display winner or draw message across the board
function showWinnerText(message) {
  winText.textContent = message;
  winMessage.classList.remove("hidden");
}

// Initialize
restartGame();
